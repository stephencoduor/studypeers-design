<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['linkedin_app_id']              = '78q4qs4eba4nt8';
$config['linkedin_app_secret']          = 'q2eyrgvLjo3Z8QdU';
$config['linkedin_login_type']          = 'socialLogin/linkedinCallback';
$config['linkedin_scope']               = 'r_basicprofile r_emailaddress';

?>

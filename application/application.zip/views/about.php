<section class="section-padding" style="padding: 138px 0;">
<div class="hs_service_main_wrapper" style="padding-top:2%;padding-bottom:1%">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                <div class="hs_about_heading_main_wrapper">
                    <div class="hs_about_heading_wrapper">
                        <h1>About Us</h1>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container" style="padding-bottom: 20px" >
      <div class="row">
      	<div class="col-sm-12">
      		<p >Study Peers is a service platform where all your worries related to future comes to an end. As we all know that the movement of stars and planet influence the whole natural world in this situation Study Peers provide future prediction through kundli, horoscope, date of birth and through location of birth. Top - notch and industry trusted astrologer available 24 / 7 on calls chat reports and query to solve the problem and give a hope for the future.<br><br>Talk to the expert of your choice on calls, chat, reports and query at reasonable price and get prediction on love life, marriage, carrier, education, health and family the service provided is through website and apps. The services are full confidential and the payment is 100% secure.<br><br>&nbsp;Anamika Singh</p>
    <p><br>&nbsp;Founder :</p>
    <p><br>&nbsp;MBA &nbsp;ICFAI</p>
      	</div>
    </div>
</div>
</section>


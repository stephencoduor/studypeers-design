<section class="hero-section" style="padding-top: 150px;background-color:#e7e5e5">
<div class="container margin_60" style="padding-bottom: 20px">
	<div class="row justify-content-center">
		
		<div class="col-xl-6 col-lg-6 col-md-8">
			<div class="box_account">
				<h3 class="client"><?php echo get_phrase('Email Verified Successfully'); ?></h3>
				<p>Congratulations ! You have successfully verified your institution email. Please <a href="<?php echo base_url(); ?>home/login" style="color:#0056b3;">login</a> to continue</p>
			</div>
		</div>
	</div>
</div>
</section>
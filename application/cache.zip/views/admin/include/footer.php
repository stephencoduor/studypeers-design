<!-- Footer -->
      <footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-6">
            <div class="copyright text-center  text-lg-left  text-muted">
              &copy; 2020 <a href="<?php echo base_url(); ?>" class="font-weight-bold ml-1" target="_blank">Studypeers</a>
            </div>
          </div>
          
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  
  <script src="<?php echo base_url(); ?>assets_a/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets_a/vendor/js-cookie/js.cookie.js"></script>
  <script src="<?php echo base_url(); ?>assets_a/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="<?php echo base_url(); ?>assets_a/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="<?php echo base_url(); ?>assets_a/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="<?php echo base_url(); ?>assets_a/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="<?php echo base_url(); ?>assets_a/js/argon.js?v=1.2.0"></script>
</body>

</html>
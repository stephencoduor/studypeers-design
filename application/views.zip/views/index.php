<?php include 'layouts/header.php'; ?>
<?php include $page_name.'.php'; ?>
<?php include 'layouts/footer.php';?>
 
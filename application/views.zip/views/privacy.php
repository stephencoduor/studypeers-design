<style type="text/css">
    h2,h3,h4,h5,p,ul li {
    font-family: sans-serif;
    line-height: 25px;
    /*text-align: justify;*/
}

</style>
<section class="section-padding" style="padding: 138px 0;">
<div class="hs_service_main_wrapper" style="padding-top:2%;padding-bottom:1%">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                <div class="hs_about_heading_main_wrapper">
                    <div class="hs_about_heading_wrapper">
                        <h1>Privacy policy and dispute</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container" style="padding-bottom: 20px" >
      <div class="row">
        <div class="col-sm-12">
            <p >Any unauthorized use of OnlineAstrotalk platform by any person other than its users and astrologer will be treated against the law and is punishable under different section of IPC.</p>
            <p>All the dispute related to agreement, term and condition, consent or unauthorised use should be filed in the court &nbsp;within 18 months from the date on which such case has come to &nbsp;existence.</p>
            <p>All the dispute regarding the service site are any concern related to onlineastrotalk will we &nbsp;be governed by Indian law &nbsp;and both the parties are bound to agree to the &nbsp;exclusive jurisdiction the New Delhi court.</p>
            <p>If the service provided through our platform give you satisfaction it will be our pleasure. We would be pleased to to serve you again and we also welcome Idea and tips for improvements.</p>
        </div>
    </div>
</div>
</section>
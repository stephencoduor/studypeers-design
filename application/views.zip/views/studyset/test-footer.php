
			
    
    <script src="<?php echo base_url(); ?>assets_d/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets_d/js/Chart.bundle.js"></script>
	<script src="<?php echo base_url(); ?>assets_d/js/utils.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
	<script src="https://areaaperta.com/nicescroll/js/jquery.nicescroll.plus.js"></script>
	<script src="https://areaaperta.com/nicescroll/js/jquery.nicescroll.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
	<script src="<?php echo base_url(); ?>assets_d/js/jquery.star-rating-svg.js"></script>
	<script src="https://momentjs.com/downloads/moment.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.43/js/bootstrap-datetimepicker.min.js"></script>
	<?php if($index_menu == 'questions') { ?>
		<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets_d/js/jquery-te-1.4.0.min.js" charset="utf-8"></script> -->
	<?php } ?>
    <script src="<?php echo base_url(); ?>assets_d/js/custom.js"></script>

    <script>
    	

	    function showModal(){
		    $('#TestModalAll').modal('show');
		 }

	    showModal();
	  	// $('#jqte-test').jqte();

	</script>

</body>
</html>
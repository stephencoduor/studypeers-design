<style type="text/css">
	h1,h2,h3,p,h5,p,ul li {
    font-family: sans-serif;
    line-height: 25px;
    text-align: justify;
}
ul, li{
     list-style-type: square;
   
}
</style>
<section class="section-padding" style="padding: 138px 0;">
<div class="hs_service_main_wrapper" style="padding-top:2%;padding-bottom:1%">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                <div class="hs_about_heading_main_wrapper">
                    <div class="hs_about_heading_wrapper">
                        <h2>Terms & Conditions</h2>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container" style="padding-bottom: 20px" >
      <div class="row">
        <div class="col-sm-12">
            <p >www.onlineastrotalk.com or www.onlineastrotalk.in  (  Managed by M/S PARTY AT GOLF COURSE.)  gives you access to its services on the given  term and conditions .</p><br>
            <p>The member agrees to term and conditions while using the services of onlinastrotalk.com .
Before using our services please read the terms and conditions carefully on our website www.onlineastrotalk.com or www.onlineastrotalk.in . You  agree with term and conditions is signified once you click "I AGREE" button onlineastrotalk reserves the full right to amend these terms and condition at any point of the time and post amended terms and conditions on our website.
Once amended terms and conditions are posted on our website and if you are a member prior to this amendment you continue to use our website it will signify that you accept such changes. If there is a written agreement between you and www.onlineastrotalk.com in such case you are free to to refuse amended terms and conditions.
</p>
<br>
<h3><b>OnlineAstroTalk objects:</b></h3>
<p>The main objective of our company is to provide astrological consultation and guidance based on horoscope, date of birth and location of birth  world wide. we provide services over phone calls, chat, on query and through reports. you can simply avail our services by visiting  onlineastrotalk.com or our mobile app.
A team of verified and trusted astrologer working 24/7 to provide services on paid basis.
</p>
<br>
<h3><b>Who are eligible for Registration:</b></h3>
<p>Any person who wants to take the services of our astrologers through our website or app should have been attended a minimum  18 years of age and should not be  under any legal disability. All the services will be paid and the company has full authority to reject a member if  the information provided by him or her is incorrect or incomplete. To register as a member you need to give full details to the company and the same will be fully secured.
</p>
<br>
<h3><b>Terms and conducts for users:</b></h3>
<p><ul style="list-style-type: square;">
	<li>Once the user registered on our website downloaded our app we see can concert the Astrologer of his /her choice from the given panel.</li><br>
	<li>The user if you want can concert more than one astrologer but the charges for all will be different and cannot be combined.</li><br>
	<li>The user need to recharge his /her wallet before  trying to consult the Astrologer.</li><br>
	<li>The wallet will be provided by online astro talk in the app and the website and the charges for consultation will be detected accordingly once you recharge.</li><br>
	<li>Call or chat can be disconnected if there is not available balance left in your wallet.</li><br>
	<li>All the Astrologer might not be available all the time and you you will have to choose from the one who are available or can wait for others to be online.</li><br>
	<li>Your call or chat with astrologer can be recorded for the further assistance.</li>
</ul>
</p>
<br>
<h3><b>Refund and liability:</b></h3>
<p><ul style="list-style-type: square;">
	<li>Charges once deducted for call or chat cannot be refunded.</li>
	<br>
	<li>Onlineastrotalk would not be  responsible or liable for any information share between astrologer and the user. The use of such information should be on your own risk.</li>
	<br>
	<li>Any network aur coverage issue in the user phone will be responsibility of user and not off onlineastrotalk and the charges deducted for the same will not be refunded.</li>
	<br>
	<li>The report ordered will be shared within 24 hours but in case  of some unusual circumstances it may take more time and the refund cannot be given for  delay.</li>
	<br>
	<li>The query will be answered within 24 hours but it my take more time in some unusual circumstances.</li>
	<br>
	<li>Advice given by astrologer to user in good faith and onlineastrotalk makes no  warranty to the same.</li>
</ul>
</p>
<br>
<h3><b>WHO CAN REGISTER AS AN ASTROLOGER :</b></h3>
<p><b>Any person who have attended an age of  18 years and above and has a a renowned degree or expertise in the field of astrology, numerology, tarot reading and other related fields of astrology and  is willing to share the platform to give advice and guidance to the users can register on our site with certain terms and conditions which are the mentioned in the below paragraphs.</b></p>
<br>
<h3><b>Consent and Conduct of Members:</b></h3>
<p>By clicking the term " I AGREE " the members give their consent :</p><br>
<p><ul style="list-style-type: square;">
	<li>to call send SMS and emails to their number even if they have activated DND.</li>
	<br>
	<li>to use the details provided by them by agent or astrologer to give them accurate solution to the  problem or or any complaints arising.</li>
	<br>
	<li>members give their consent that they will use the platform for taking services of the Astrologer at not for any commercial use.</li>
	<br>
	<li>the details provided by members are correct and accurate</li>
	<br>
	<li>advice provided by the Astrologer will only be on astrology and not on any other jurisdiction .</li>
	<br>
	<li>any disturbance to service, network, site, or the Goodwill of online astrotalk due to members  will be punishable under Indian panel code.</li>
</ul>
</p>
<br>
<h3><b>Contents on the Site :</b></h3>
<p>All the proprietary right are reserved and owned by OnlineAstroTalk . We provide advice and guidance on the basis of data provided by members and this advice or gudince cannot be  in any form be used for medical for legal purpose.</p>
<br>
<h3><b>Terms of Astrologer Conduct:</b></h3>
<p><ul style="list-style-type: square;">
	<li>Once you registered on our website as an astrologer you will not contact the user directly or indirectly or ask them to contact you personally except through onlineastrotalk.</li>
	<br>
	<li>As an Astrologer you will not except or ask for any payment which is is not through onlineastrotalk.</li>
	<br>
	<li>Astrologer will give correct authentic accurate information to the user uh and not mislead the user for any benefit.</li>
	<br>
	<li>Astrologer will not share that information pertaining to website or app which is provided to them.</li>
	<br>
	<li>Astrologer will follow the rule and regulation of local national and international law prevailing at that time.</li>
	<br>
	<li>Astrologer will maintain the integrity of site and any cost not use language expression or method which is illegal and abusing for harassing in the court of law.</li>
	<br>
	<li>Astrologer will not share the payment settlement terms with any  person.</li>
	<br>
	<li>Astrologer  will not provide or advise any treatment or diagnosis  which only a medical professional are allowed to do.</li>
	<br>
	<li>Astrologer will also not provide any legal advice and ask the user to consult a legal professional as the situation demand.</li>
	<br>
	<li>Astrologer gives his or her consent to OnlineAstroTalk to send mail and sms daily remind for login.</li>
	<br>
	<li>Astrologer or OnlineAstroTalk can terminate this contract by giving a month notice but in case astrologer is proved guilty in any of his/her conduct then OnlineAstroTalk has the full right to terminate the contract then and there and the same cannot be challenge at any court of law.</li>
	<br>
	<li>Any act of astrologer which disrupts site ,service, network or the integrity of OnlineAstroTalk cannot be tolerated at any cost.</li>
</ul>
<br>
<h3><b>Payment terms for Astrologer </b></h3>
<p><ul style="list-style-type: square;">
	<li>Onlineastrotalk and the Astrologer will enter and agreement for the payment made to the Astrologer.</li>
	<br>
	<li>An account will be created by onlineastrotalk in the name of astrologer and a username and password will be  generated. The same will be forwarded to the astrologer and request will be send to change the password. Astrologer will we liable to maintain privacy of password and username. Any loss due to disclosure of same will be astrologer's sole responsibility but in case any loss to the onlineastrotalk due to this act will be punishable.</li>
	<br>
	<li>The Astrologer payment part can be withdrawn at the end of every month after reduction of applicable taxes and charges.</li>
</ul>


        </div>
    </div>
</div>
</section>
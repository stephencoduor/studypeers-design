
<h1 style="text-align: center">Your detail has send. with in 24 hour we notify in your registerd email nd Mobile no </h1>
﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'ar', {
	copy: 'حقوق النشر &copy; $1. جميع الحقوق محفوظة.',
	dlgTitle: 'عن CKEditor',
	moreInfo: 'للحصول على معلومات الترخيص ، يرجى زيارة موقعنا:'
} );

﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'el', {
	copy: 'Πνευματικά δικαιώματα &copy; $1 Με επιφύλαξη παντός δικαιώματος.',
	dlgTitle: 'Περί του CKEditor 4',
	moreInfo: 'Για πληροφορίες σχετικές με την άδεια χρήσης, παρακαλούμε επισκεφθείτε την ιστοσελίδα μας:'
} );

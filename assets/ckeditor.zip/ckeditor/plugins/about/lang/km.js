﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'km', {
	copy: 'រក្សាសិទ្ធិ &copy; $1។ រក្សា​សិទ្ធិ​គ្រប់​បែប​យ៉ាង។',
	dlgTitle: 'អំពី CKEditor',
	moreInfo: 'សម្រាប់​ព័ត៌មាន​អំពី​អាជ្ញាបណញណ សូម​មើល​ក្នុង​គេហទំព័រ​របស់​យើង៖'
} );
